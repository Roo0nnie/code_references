
	
		Binary Search is a searching algorithm for finding an element's position 			
	in a position in a sorted array. The element is always searched in the middle 
	of a portion of an array.

		Binary search can be implemented only on a sorted list of items. If the
	elements are not sorted already, we need to sort them first.


			BINARY SEARCH WORK
		
		* Iterative Method
		* Recursive Method