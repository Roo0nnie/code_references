/* Node of a doubly linked list */
#include <stdio.h>

int main() {

struct Node {
    int data;
    struct Node* next; // Pointer to next node in DLL
    struct Node* prev; // Pointer to previous node in DLL
    
    
};
return 0;	
}

