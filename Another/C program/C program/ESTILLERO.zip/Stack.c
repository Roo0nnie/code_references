				ABSTRACT STACK
											 	LIFO( Last In First Out ):
	Stack - It is a linear data structure that follows a particular order	 	
		in which the operations are performed.					
											This strategy states that the element that is inserted last will come out 
										first.You can take a pile of plates kept on top of each other as a real-life 
	An Abstract Stack (Stack ADT) is an abstract data			example. The plate which we put last is on the top and since we remove the plate 
	type which emphasizes specific operations:				that is at the top, we can say that the plate that was put last comes out first.
					
	* Uses a explicit linear ordering					 
	* Insertions and removals are performed individually			BASIC OPERATION ON STACK
	* Inserted objects are pushed onto the stack					In order to make manipulations in a stack, there are certain operations 
	* The top of the stack is the most recently object pushed		provided to us.
	onto the stack							
	* When an object is popped from the stack, the current				* push() to insert an element into the stack.
	top is erased									* pop() to remove an element from the stack.
											* top() Returns the top element of the stack.
											* isEmpty() returns true is stack is empty else false.
		IMPLEMENTATION OF STACK							* size() returns the size of stack.

	There are two ways to implement a stack

	* Using array
	* Using linked list
	
	Standard Problem On Stack:
		
	 [1]. Infix to Postfix Conversion
	 [2]. Prefix to Infix Conversion
	 [3]. Prefix to Postfix Conversion
	 [4]. Postfix to Prefix Conversion
	 [5]. Postfix to Infix Conversion
	 [6]. Infix to Prefix Conversion
	 
	 [0] Back     [9] QUIT

