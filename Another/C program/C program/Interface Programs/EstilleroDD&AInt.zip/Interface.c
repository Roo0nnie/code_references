#include <stdio.h>
#include <stdlib.h>

void Bubble() {
	
  int array[100], size, i, j, swap,Noswap=0,NoCom=0;
  	
  system("cls");
  printf("\n");
  printf("\t\t\t\t\t\t\t\t\t\tBUBBLE SORT\n\n");
  printf("     				Bubble sort is a sorting algorithm that compares two adjacent elements and ");
  printf("swaps them if they are not in the intended order.");
  
  printf("\n\nEnter number of elements: ");
  scanf("%d", &size);
  printf("Enter %d integers: ", size);
  	for (i = 0; i < size; i++)
   		 scanf("%d", &array[i]);
 			 for (i = 0 ; i< size - 1; i++) {
    			for (j = 0 ; j < size - i - 1; j++) {
      				if (array[j] > array[j+1]) {
        				swap       = array[j];
        				array[j]   = array[j+1];
       					 array[j+1] = swap;
        				Noswap++;
      }NoCom++;
    }
  }
  	printf("Ascending order: ");
  		for (i = 0; i < size; i++) {
  	   		printf("%d ", array[i]);
  }
    printf("\n\nNumber of swap: %d\n", Noswap);
    printf("Number of compare: %d", NoCom);
	printf("\n\nPress any key to exit...\n");	
	getchar();
	getchar();
}
void Selection() {
	
  int array[100], size, i, j, location, t;	
  
  system("cls");
  printf("\n");
  printf("\t\t\t\t\t\t\t\t\t\tSELECTION SORT\n\n");
  printf("     				The selection sort algorithm sorts an array by repeatedly finding the minimum ");
  printf("element (considering ascending order) from\n");
  printf("     	unsorted part and putting it at the beginning. The algorithm maintains two subarrays in a given array.\n\n\n\n");
  
  	printf("Enter number of elements: ");
	scanf("%d", &size);
  	
  printf("Enter %d integers: ", size);
 	 for (i=0;i<size;i++)
    	scanf("%d", &array[i]);
  			for (i=0;i<(size-1);i++) {
    			location = i;
    			for (j=i+1;j<size;j++) {
      				if (array[location] > array[j])
      				location = j;
   				 } if (location != i) {
      				t = array[i];
      				array[i] = array[location];
      				array[location] = t;
    		}
  		}
  		
  printf("Sorted list in ascending order: ");
  		for (i= 0;i< size; i++) {
  			printf("%d ", array[i]);
  		}	printf("\n\n\nPress any key to exit...\n");	
	getchar();
	getchar();
}
void Insertion() {
	
  int i, j, size, temp,array[100],k=0;
  	
  system("cls");
  printf("\n");
  printf("\t\t\t\t\t\t\t\t\t\tINSERTION SORT\n\n");
  printf("     				It is a sorting algorithm that builds the final sorted array one item at a time. Elements are transfered\n");
  printf(" 		one by one  at a time to the right position.\n\n\n\n");

	printf("Enter number of elements: ");
	scanf("%d",&size);
  		printf("Enter %d element/s: ", size);
   			for(i=0;i<size;i++) 
    			scanf("%d", &array[i]); 	
   			for(i=1;i<size;i++) {
      		temp=array[i];
      		j=i-1;
      		while((temp<array[j])&&(j>=0)){
         		array[j+1]=array[j];
         		j=j-1;
         		k++;
      		}
      array[j+1]=temp;
   }
   printf("Sorted list in ascending order: ");
   		for(i=0;i<size;i++) {
   	printf(" %d",array[i]);
   }
   	printf("\n\nNumber of swap: %d",k);
	printf("\n\n\nPress any key to exit...\n");	
	getchar();
	getchar();
}
void Line() {
	
	int array[100], search, i, size,k=0;
	
    system("cls");
  	printf("\n");
	printf("\t\t\t\t\t\t\t\t\t\tLINEAR\n\n");
  	printf("     				A linear search, also known as a sequential search, is a method of finding an element within a list. It checks\n");
  	printf(" 		each element of the list sequentially until a match is found or the whole list has been searched..\n\nSample program......\n\n\n");
  	  
	printf("Enter number of elements: ");
	scanf("%d", &size);
  	printf("Enter %d integer(s): ", size);
  		for (i = 0; i < size; i++)
    	scanf("%d", &array[i]);
  	printf("Enter a number to search: ");
  	scanf("%d", &search);
  		for(i=0;i< size; i++) {
    		if (array[i] == search) {
      			printf("\n%d is present at index %d.\n", search, i);
      			break;
    	}k++;
  	} if(k==size) {
  		printf("\n%d isn't present in the array.\n\n\n", search);
  }
	printf("Press any key to exit...\n");	
	getchar();
	getchar();
}
void Binary() {
	
	int i, j, size, temp,array[100],k=0,search,middle,last,first;
	char input[200];
	FILE *file = fopen("Binary.c", "r");	
	
	system("cls");
	printf("\n");
	printf("\t\t\t\t\t\t\t\t\t\tBINARY SEARCH\n\n");

	if(file == NULL) {
		printf("No File Found!\n");
	} else {
		while(fgets(input, 200, file) != NULL) {
			printf("%s", input);
		}
	}
	fclose(file);
	
  	printf("\n\nSample program:\n\nEnter number of elements: ");
  	scanf("%d",&size);
  	printf("Enter %d element/s: ", size);
   		for(i=0;i<size;i++) 
     		scanf("%d", &array[i]); 	
   			for(i=1;i<size;i++) {
      		temp=array[i];
      		j=i-1;
      		
      while((temp<array[j])&&(j>=0)){
         array[j+1]=array[j];
         j=j-1;
         k++;
      }
      array[j+1]=temp;
   }
   		printf("Enter the value to find: ");
     	scanf("%d",&search);
   		printf("\nSorted array[]: ");
   			for(i=0;i<size;i++) {
	   			printf(" %d",array[i]);
	}
   first = 0;
   last = size - 1;
   middle = (first+last)/2;
   
   while (first <= last) {
      if (array[middle] < search) {
 		 first = middle + 1;        	
	  } else if (array[middle] == search) {
         printf("\n%d is present at index %d.\n\n", search, middle);
         break;
      } else
         last = middle - 1;
      	 middle = (first + last)/2;
   }
   if (first > last)
    	printf("\n%d isn't present in the array.\n\n", search);
		printf("Press any key to exit...\n");	
		getchar();
		getchar();
}
int factorial(int n) {  
  if (n == 0)  
    return 1;  
  else  
    return(n * factorial(n-1));  
}  
void Fact() {
	
    int number,fact;  	
	
	system("cls");
	printf("\n");
	printf("\t\t\t\t\t\t\t\t\t\tFACTORIAL\n\n");
  	printf("     				Factorial of n is the product of all positive descending integers. Factorial of n is denoted by n!.\n");
  	printf("\nSample program......\n\n\n");
  	
	printf("Enter a number: ");  
  	scanf("%d", &number);   
   
  	fact = factorial(number);  
  	
	printf("Factorial of %d is %ld\n", number, fact);	
	printf("Press any key to exit...\n");	
	getchar();
	getchar();
}
void fi(int num){    
    static int num1=0,num2=1,num3;    
    if(num>0){    
         num3 = num1 + num2;    
         num1 = num2;    
         num2 = num3;    
         printf("%d ",num3);    
         fi(num-1);    
    }    
} 
void Fibb() {
	
    
	int num; 
	system("cls");
	printf("\n");
	printf("\t\t\t\t\t\t\t\t\t\tFIBONACCI SERIES\n\n");
  	printf("     				Fibonacci is a series of number which the next number is the sum of previous two number. The first two numbers\n");
  	printf(" 		of fibonacci series are 0 and 1.\n\nSample program......\n\n\n");
   
    printf("Enter the number of elements: ");    
    scanf("%d",&num);    
    printf("Fibonacci Series: ");    
    printf("%d %d ",0,1);    
    fi(num-2); 
	getchar();	
	getchar();
}
void Gcd() {
	
	int num1,num2,gcd=1,i;
	
	system("cls");
	printf("\n");
	printf("\t\t\t\t\t\t\t\t\t\tGREATEST COMMON DIVISOR\n\n");
  	printf("     				 It is the highest number that completely divides two or more numbers. It is abbreviated for GCD. It is also\n");
  	printf(" 		known as the Greatest Common Factor (GCF) and the Highest Common Factor (HCF). It is used to simplify the fractions.\n\nSample program......\n\n\n");	
	
	printf("Enter 2 number to find its GCD: ");
	scanf("%i %i", &num1, &num2);
	
	for(i=1;i<=num1 && i<=num2; i++) {
		if(num1%i == 0 && num2%i == 0) {
			gcd = i;
		}
	}	printf("The GCD of %d and %d is %d.",num1,num2,gcd );
	getchar();	
	getchar();
}

void Graphs() {
	
	char input[200];
	
	system("cls");
	printf("\n");
	printf("\t\t\t\t\t\t\t\t\t\tGRAPH\n\n");

	FILE *file = fopen("Graph.c", "r");
	
	if(file == NULL) {
		printf("No File Found!\n");
	} else {
		while(fgets(input, 200, file) != NULL) {
			printf("%s", input);
		}
	}
	fclose(file);
	printf("\n\nPress any key to exit...\n");	
	getchar();
	NonLinearFun();
}
void Trees() {
	char input[200];
	
	system("cls");
	printf("\n");
	printf("\t\t\t\t\t\t\t\t\t\tTREE\n\n");

	FILE *file = fopen("Tree.c", "r");

	if(file == NULL) {
		printf("No File Found!\n");
	} else {
		while(fgets(input, 200, file) != NULL) {
			printf("%s", input);
		}
	}
	fclose(file);
	printf("\n\nPress any key to exit...\n");	
	getchar();
	NonLinearFun();
}
void Return() {
	getchar();
	Title();
}

void getback() {
	getchar();
	main();
}
void NonLinearFun() {
	getchar();
	NonLinear();
}
void LinearFun() {
	getchar();
	Linear();
}
void Array() {

	char input[200];
	
	system("cls");
	printf("\n");
	printf("\t\t\t\t\t\t\t\t\t\tARRAY\n\n");

	FILE *file = fopen("Array.c", "r");

	if(file == NULL) {
		printf("No File Found!\n");
	} else {
		while(fgets(input, 200, file) != NULL) {
			printf("%s", input);	
		}
	}
	fclose(file);
	printf("\n\nPress any key to exit...\n");	
	getchar();
	LinearFun();
}
void LinkedList() {
	
	char input[200];	
	
	system("cls");
	printf("\n");
	printf("\t\t\t\t\t\t\t\t\t\tLINKED LIST\n\n");

	FILE *file = fopen("LinkedList.c", "r");
	
	if(file == NULL) {
		printf("No File Found!\n");
	} else {
		while(fgets(input, 200, file) != NULL) {
			printf("%s", input);
		}
	}
	fclose(file);
	printf("\n\nPress any key to exit...\n");	
	getchar();
	LinearFun();
}
void Stack() {

	char input[200];

	system("cls");
	printf("\n");
	printf("\t\t\t\t\t\t\t\t\t\tSTACK\n\n");

	FILE *file = fopen("Stack.c", "r");

	if(file == NULL) {
		printf("No File Found!\n");
	} else {
		while(fgets(input, 200, file) != NULL) {
			printf("%s", input);
		}
	}
	fclose(file);
	printf("\n\nPress any key to exit...\n");	
	getchar();
	LinearFun();
}
void Queue() {

	char input[200];

	system("cls");
	printf("\n");
	printf("\t\t\t\t\t\t\t\t\t\tQUEUE\n\n");

	FILE *file = fopen("Queue.c", "r");
	
	if(file == NULL) {
		printf("No File Found!\n");
	} else {
		while(fgets(input, 200, file) != NULL) {
			printf("%s", input);
		}
	}
	fclose(file);
	printf("\n\nPress any key to exit...\n");	
	getchar();
	LinearFun();	
}
void Sort() {
	
	char c;
	
	system("cls");
	printf("\n");
	printf("		SORTING\n");
	printf("		_______\n\n");
	printf("	[1] Bubble Sort\n");
	printf("	[2] Selection Sort\n");
	printf("	[3] Insertion Sort\n\n");
	printf("	[0] Back\n");
	printf("	[9] QUIT\n");
	printf("\n");
	
	do {
		printf("Select: ");
		c = getchar();
		
	} while (c != '1' && c != '2' && c != '3' && c != '0' && c != '9');
	
	if(c == '1') {
		Bubble();
		Sort();
	} else if(c == '2' ) {
		Selection();
		Sort();
	} else if(c == '3') {
		Insertion();
		Sort();
	} else if (c == '0') {
		Return();
	} else {
		getback();	 
	}
}	
void Search() {
	
	char c;
	
	system("cls");
	printf("\n");
	printf("		SEARCHING\n");
	printf("		________\n\n");
	printf("	[1] Binary Search\n");
	printf("	[2] Linear Search\n\n");
	printf("	[0] Back\n");
	printf("	[9] QUIT\n");
	printf("\n");
	
	do {
		printf("Select: ");
		c = getchar();
		
	} while (c != '1' && c != '2' && c != '0' && c != '9');
	
	if(c == '1') {
		Binary();
		Search();
	} else if(c == '2' ) {
		Line();
		Search();
	} else if (c == '0') {
		Return();
	} else {
		getback();	 
	}
}	
void Recursive() {

	char c;
	
	system("cls");
	printf("\n");
	printf("		Recursive\n");
	printf("		_________\n\n\n");
	printf("	[1] Fibonnacci\n");
	printf("	[2] Factorial\n");
	printf("	[3] GCD\n");
	printf("	[0] Back\n");
	printf("	[9] QUIT\n");
	printf("\n");
	
	do {
		printf("Select: ");
		c = getchar();
	} while (c != '1' && c != '2' && c != '3' && c != '0' && c != '9');
	if(c == '1') {
		Fibb();
		Recursive();
	} else if(c == '2' ) {
		Fact();
		Recursive();
	} else if(c == '3') {
		Gcd();
		Recursive();
	} else if (c == '0') {
		Return();
	} else {
		getback();	 
	}
}
void Linear() {

	char c;
	
	system("cls");
	printf("\n");
	printf("		Linear Data Structures\n");
	printf("		______________________\n\n\n");
	printf("	[1] Array\n");
	printf("	[2] Linked List\n");
	printf("	[3] Stack\n");
	printf("	[4] Queue\n\n");
	printf("	[0] Back\n");
	printf("	[9] QUIT\n");
	printf("\n");
	
	do {
		printf("Select: ");
		c = getchar();
	} while (c != '1' && c != '2' && c != '3' && c != '4' && c != '0' && c != '9');
	if(c == '1') {
		Array();
		Linear();
	} else if(c == '2' ) {
		LinkedList();
		Linear();
	} else if(c == '3') {
		Stack();
		Linear();
	} else if (c == '4') {
		Queue();
		Linear();
	} else if (c == '0') {
		Return();
	} else {
		getback();	 
	}
}
void NonLinear() {

	char c;
	
	system("cls");
	printf("\n");
	printf("		Non-Linear Data Structures\n");
	printf("		__________________________\n\n\n");
	printf("	[1] Graphs\n");
	printf("	[2] Trees\n\n");
	printf("	[0] Back\n");
	printf("	[9] QUIT\n");
	printf("\n");
	
	do {
		printf("Select:");
		c = getchar();
	} while (c != '1' && c != '2' && c != '0' && c != '9');
	if(c == '1') {
		Graphs();
		NonLinear();
	} else if(c == '2' ) {
		Trees();
		NonLinear();
	} else if (c == '0') {
		Return();
	} else {
		getback();
	}	
}
void Quadratic() {
	
	int a,b,c, disc = 0;
	int den = 0,x = 0, x1 = 0, x2 = 0;	
	
	system("cls");
	printf("\n");
	printf("\t\t\t\t\t\t\t\t\t\tQUADRATIC EQUATION\n\n");
  	printf("     				  a quadratic equation is any equation that can be rearranged in standard form as a x 2 + b x + c = 0.\n");
  	printf(" 		Polynomial equation in a single variable where the highest exponent of the variable is 2.\n\nSample program......\n\n\n");

	printf("Enter the value of A, B, C:");
	scanf("%d %d %d", &a, &b, &c);
	
	disc = ((b * b) - 4 *(a * c));
	den = 2 * a;
	
	if(disc > 0) {
		x1 = (-b + sqrt(disc) / den);
		x2 = (-b - sqrt(disc) / den);
		printf("%.3f\n", x1);
		printf("%.3f\n", x2);
	} else if(disc == 0) {
		x = (-b / den);
		printf("%.3f\n", x);
	} else {
		printf("No solution!\n");
	}
	printf("\n\nPress any key to exit...\n");	
	getchar();
	Return();
}
void Title() {
	
	char c;
	
	system("cls");
	printf("\n");
	printf("		DATA STRUCTURE & ALGORITHM\n");
	printf("		__________________________\n\n\n");
	printf("	[1] Linear Data Structures\n\n");
	printf("	[2] Non-Linear Data Structures\n\n");
	printf("	[3] Searching\n\n");
	printf("	[4] Sorting\n\n");
	printf("	[5] Recursive\n\n");
	printf("	[6] QUADRATIC EQUATION\n\n");
	printf("	[0] Quit\n");
	printf("\n");
	
	do {
		printf("Select:");
		c = getchar();
		
	} while (c != '0' && c != '1' && c != '2' && c != '3' && c != '4' && c != '5' && c != '6');
	if(c == '1') {
		Linear();
		Title();
	} else if(c == '2' ) {
		NonLinear();
		Title();
	} else if(c == '3'){
		Search();
		Title();	
	} else if (c == '4') {
		Sort();
		Title();
	} else if(c == '5') {
		Recursive();	
	} else if(c == '6') {
		Quadratic();
		Title();	
	} else {
		getback();
	}	 
}
main () {
	
	system("cls");
	printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
	printf("										WELCOME\n\n");
	printf("\									   	  TO\n\n");
	printf("								   	DATA STRUCTURE & ALGORITHM\n\n\n\n");
	printf("								          Ronnie F. Estillero\n");
	printf("								        	BSIT 2A\n\n\n\n");

	printf("Press any key to continue.....\n");
	getchar();
	Title();
}
