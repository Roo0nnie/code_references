let suggestions = [
    "Frothy Whipped",
    "Chimney Devil",
    "Roasted Coffee",
    "Chimney Cream",
    "Ube Cramble",
    "Uberries Cramble",
    "Hot Chocolate",
    "Violet Moon",
    "Cappaccino",

];
