public class Car{
	public Car(){
		System.out.println("Im here in Car Constructor");
	}
}