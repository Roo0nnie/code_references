public class CarMain{
	public static void main(String args[]){
	
		VariantG objVar = new VariantG();
	
		System.out.println("Name : " + objVar.getName());
	}


}