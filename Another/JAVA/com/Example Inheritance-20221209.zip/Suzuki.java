public class Suzuki extends Car{
	public Suzuki(){
		System.out.println("Im here in Suzuki Constructor");
	}
}