public class VariantG extends Innova{
	public VariantG(){
		//super(100);
		super.name = "JOSE RIZAL";
		System.out.println("Im here in VariantG Constructor");
	}
}